import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session
import random

## database stuff
## I used perplexity (prompt was "hw to have python creeate and edit a sql database tutorial video")
# to find this video which walks you through building as well as editing databases in python (https://youtu.be/XYxXbHL-Dbo)
users_info = sqlite3.connect("users_info.db")
shortened_URL = sqlite3.connect("shortened_URL.db")
users_cursor = users_info.cursor()
shortened_URL_cursor = shortened_URL.cursor()

## Creates a database named USERS_INFO with the columns USER_ID, USERNAME, and USER_PASSWORD
users_cursor.execute("""CREATE TABLE IF NOT EXISTS USERS_INFO ( 
 USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
 USERNAME TEXT,
 USER_PASSWORD TEXT)""")

shortened_URL_cursor.execute("""PRAGMA foreign_keys = ON;""")  ## ensures foreign key enforcement isn't ignored

## Creates a database named SHORTENED_URL with the columns URL_ID, USER_ID, SHORTENED_URL and ORIGINAL_URL
# and connects to the user_id from USER_INFO making the one in SHORTENED_URLS foreign key
shortened_URL_cursor.execute("""CREATE TABLE IF NOT EXISTS Shortened_URLS (
URL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
USER_ID INTEGER,
Shortened_URL TEXT,
ORIGINAL_URL TEXT,
FOREIGN KEY (USER_ID ) REFERENCES USERS_INFO(USER_ID)
)""")

## flask stuff
## Used digital Ocean in order to learn how to create and use a flask application
app = Flask(__name__)
app.secret_key = 'key'

## these create the different pages on the website and then go into templates to see how they should be built
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('Main_Page.html')

## allows us to get and post information from signup and gets the information that you give during sign up and stores it in the users_info database
@app.route('/SignUp', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']

        password = request.form['password']

        confirm_password = request.form['confirm_password']

        if password != confirm_password: ## makes sure that the passwords match and if they don't then it will return that the passwords don't match
            return "The passwords do not match"

        ## checks to see if that username is already taken
        conn = sqlite3.connect('users_info.db')
        cursor = conn.cursor()
        cursor.execute("SELECT USER_ID FROM USERS_INFO WHERE USERNAME=?", (username,))
        if cursor.fetchone():
            conn.close()
            return "User already exists"

        ##creates user by inserting the supplied information into the database
        users_info = sqlite3.connect('users_info.db')
        cursor = users_info.cursor()
        cursor.execute("INSERT INTO USERS_INFO (USERNAME, USER_PASSWORD) values (?,?)",(username,password)) ## inserts the gathered data into the database the question marks are placeholders for the actual information
        users_info.commit()
        ## automatically brings you to the user_urls template after creating an account and grabbing your user id
        cursor.execute("SELECT USER_ID FROM USERS_INFO WHERE USERNAME=?", (username,))
        user_id = cursor.fetchone()[0]
        session["user_id"] = user_id

        conn.close()
        return redirect(url_for('user_urls'))



    return render_template('SignUpPage.html')
## handles all logins request by checking if the provided username and password match the one we have stored
@app.route('/Login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('users_info.db')
        cursor = conn.cursor()
        cursor.execute("SELECT USER_ID FROM USERS_INFO WHERE USERNAME=? AND USER_PASSWORD=?", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user: ## if the user successfully logs in it takes them to user urls
            session["user_id"] = user[0]
            return redirect(url_for('user_urls'))

        else: ## if the user fails to login it will tell them invalid username or password
            return render_template('LoginPage.html', error="Invalid username or password")

    return render_template('LoginPage.html')

##handles everything on the user_urls template first is the deleting function which looks through the database and deletes the data from it when the user_id matches the with the text
@app.route('/USER_URLS', methods=['GET', 'POST'])
def user_urls():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']

    if request.method == 'POST':

        if request.form.get('action') == 'delete':
            short_code = request.form.get('short_code')
            conn = sqlite3.connect('shortened_URL.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Shortened_URLS WHERE USER_ID=? AND Shortened_URL = ?", (user_id,short_code))
            conn.commit()
            conn.close()
            return redirect(url_for('user_urls'))

        original_url = request.form['original_url']
        short_URL = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=6))## randomly picks 6 characters from the provided list of valid characters

        conn = sqlite3.connect('shortened_URL.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Shortened_URLS (USER_ID, Shortened_URL, ORIGINAL_URL) VALUES (?, ?, ?)", (user_id, short_URL, original_url)) ## inserts the user_id of the person that created the new url and also inserts the shortened and original url
        conn.commit()
        conn.close()
        return redirect(url_for('user_urls'))

    conn = sqlite3.connect('shortened_URL.db')
    cursor = conn.cursor()
    cursor.execute("SELECT Shortened_URL, ORIGINAL_URL FROM Shortened_URLS WHERE USER_ID = ?", (user_id,)) ##shows all shortened and original urls for a specific user determined by their id
    shortened_URLs = cursor.fetchall()
    conn.close()

    return render_template('User_URLs.html', urls=shortened_URLs)

@app.route('/<short_code>', methods=['GET']) ## this is what is redirecting the shortened url to the original url
def redirect_shor_url(short_code):
    conn = sqlite3.connect('shortened_URL.db') ## connects to database
    cursor = conn.cursor() ## creates a pointer object which allows us to use sql commands on connected databases
    cursor.execute("Select ORIGINAL_URL FROM Shortened_URLS WHERE Shortened_URL = ?", (short_code,)) ## does this code in the sql database
    result = cursor.fetchone() ##gets the row from the database
    conn.close() ## closes connection

    if result:
        original_url = result[0]
        return redirect(original_url)

    else:
        return "URL not found", 404


## tells it where to host it on as well as the port but only if __name__ == __main__
if __name__ == '__main__':
    app.run(host='localhost', port=5000)


